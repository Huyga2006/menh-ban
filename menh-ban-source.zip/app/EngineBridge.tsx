'use client';

import { useEffect } from 'react';
import { generateChart } from '@/lib/ziwei/algorithm';
import { kot, setLanguage, t } from 'iztro/lib/i18n';
import {
  calculateTrueSolarTime,
  resolveZiweiDayOffset,
  shiftGregorianDate,
} from '@/lib/ziwei/true-solar-time';
import type { BirthInfo, ZiweiChart } from '@/lib/ziwei/types';

declare global {
  interface Window {
    menhBanEngine?: {
      generateChart: typeof generateChart;
      calculateTrueSolarTime: typeof calculateTrueSolarTime;
      resolveZiweiDayOffset: typeof resolveZiweiDayOffset;
      shiftGregorianDate: typeof shiftGregorianDate;
      translate: (value: string) => string;
    };
    menhBanChart?: ZiweiChart;
  }
}

export default function EngineBridge() {
  useEffect(() => {
    setLanguage('vi-VN');
    window.menhBanEngine = {
      generateChart,
      calculateTrueSolarTime,
      resolveZiweiDayOffset,
      shiftGregorianDate,
      translate: (value) => {
        const key = kot(value) as string;
        return (t(key) as string) || value;
      },
    };
    const script = document.createElement('script');
    script.src = './app.js';
    script.async = false;
    script.onerror = () => {
      const note = document.querySelector<HTMLElement>('#engineNote');
      if (note) note.hidden = false;
    };
    document.body.appendChild(script);
    return () => {
      script.remove();
      delete window.menhBanEngine;
    };
  }, []);
  return null;
}
