(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const form = $('#birthForm');
  const dateInput = $('#birthDate');
  const timeInput = $('#birthTime');
  const citySelect = $('#birthCity');
  const chartSection = $('#chartSection');
  const formError = $('#formError');
  const engineNote = $('#engineNote');
  const branches = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
  const stems = ['甲','乙','丙','丁','戊','己','庚','辛','壬','癸'];
  const branchCoord = {'巳':'1/1','午':'1/2','未':'1/3','申':'1/4','酉':'2/4','戌':'3/4','亥':'4/4','子':'4/3','丑':'4/2','寅':'4/1','卯':'3/1','辰':'2/1'};
  const hourNames = ['Tý','Sửu','Dần','Mão','Thìn','Tỵ','Ngọ','Mùi','Thân','Dậu','Tuất','Hợi'];
  const hourRanges = ['23:00–01:00','01:00–03:00','03:00–05:00','05:00–07:00','07:00–09:00','09:00–11:00','11:00–13:00','13:00–15:00','15:00–17:00','17:00–19:00','19:00–21:00','21:00–23:00'];
  const nameFor = {
    '命宫':'Mệnh','兄弟宫':'Huynh Đệ','夫妻宫':'Phu Thê','子女宫':'Tử Tức','财帛宫':'Tài Bạch','疾厄宫':'Tật Ách','迁移宫':'Thiên Di','仆役宫':'Nô Bộc','交友宫':'Nô Bộc','官禄宫':'Quan Lộc','田宅宫':'Điền Trạch','福德宫':'Phúc Đức','父母宫':'Phụ Mẫu',
    '紫微':'Tử Vi','天机':'Thiên Cơ','太阳':'Thái Dương','武曲':'Vũ Khúc','天同':'Thiên Đồng','廉贞':'Liêm Trinh','天府':'Thiên Phủ','太阴':'Thái Âm','贪狼':'Tham Lang','巨门':'Cự Môn','天相':'Thiên Tướng','天梁':'Thiên Lương','七杀':'Thất Sát','破军':'Phá Quân',
    '左辅':'Tả Phù','右弼':'Hữu Bật','文昌':'Văn Xương','文曲':'Văn Khúc','天魁':'Thiên Khôi','天钺':'Thiên Việt','禄存':'Lộc Tồn','擎羊':'Kình Dương','陀罗':'Đà La','火星':'Hỏa Tinh','铃星':'Linh Tinh','地空':'Địa Không','地劫':'Địa Kiếp','天马':'Thiên Mã','红鸾':'Hồng Loan','天喜':'Thiên Hỷ','天姚':'Thiên Diêu','天刑':'Thiên Hình','天哭':'Thiên Khốc','天虚':'Thiên Hư',
    '禄':'Lộc','权':'Quyền','科':'Khoa','忌':'Kỵ','庙':'Miếu','旺':'Vượng','得':'Đắc','利':'Lợi','平':'Bình','不':'Bất','闲':'Nhàn','陷':'Hãm','地':'Địa',
    '金四局':'Kim Tứ Cục','木三局':'Mộc Tam Cục','水二局':'Thủy Nhị Cục','火六局':'Hỏa Lục Cục','土五局':'Thổ Ngũ Cục'
  };
  const tabs = [
    {id:'overview',label:'Tổng quan',name:'Mệnh'},
    {id:'career',label:'Sự nghiệp',name:'Quan Lộc'},
    {id:'wealth',label:'Tài lộc',name:'Tài Bạch'},
    {id:'love',label:'Tình duyên',name:'Phu Thê'},
    {id:'personality',label:'Tính cách',name:'Mệnh'}
  ];
  const starNotes = {
    'Tử Vi':'thường tượng trưng cho năng lực tổ chức, ý thức trách nhiệm và mong muốn tự chủ.',
    'Thiên Cơ':'thường gắn với sự linh hoạt, ham học hỏi và khả năng nhìn ra nhiều phương án.',
    'Thái Dương':'thường gợi tinh thần chủ động, rộng rãi và xu hướng đóng góp cho tập thể.',
    'Vũ Khúc':'thường liên hệ với tính thực tế, sự bền bỉ và khả năng quản lý nguồn lực.',
    'Thiên Đồng':'thường biểu trưng cho sự hòa nhã, biết thích nghi và coi trọng sự an ổn.',
    'Liêm Trinh':'thường gợi cá tính rõ nét, sức hút riêng và nhu cầu đặt ra nguyên tắc.',
    'Thiên Phủ':'thường gắn với sự điềm tĩnh, tích lũy và khuynh hướng gìn giữ nền tảng.',
    'Thái Âm':'thường tượng trưng cho sự tinh tế, chiều sâu cảm xúc và năng lực vun vén.',
    'Tham Lang':'thường gợi tính hiếu kỳ, khả năng giao tiếp và mong muốn trải nghiệm.',
    'Cự Môn':'thường gắn với tư duy phản biện, khả năng diễn đạt và sự chú ý đến chi tiết.',
    'Thiên Tướng':'thường gợi tinh thần hỗ trợ, sự công tâm và khả năng kết nối mọi người.',
    'Thiên Lương':'thường tượng trưng cho lòng bao dung, sự chín chắn và khuynh hướng nâng đỡ.',
    'Thất Sát':'thường gắn với sự quyết đoán, sức chịu áp lực và tinh thần hành động.',
    'Phá Quân':'thường gợi mong muốn đổi mới, thử thách lối cũ và tạo hướng đi riêng.'
  };
  let activeChart = null;
  let activeTab = 'overview';
  let toastTimer;

  function translate(value) {
    if (!value) return '';
    if (Array.isArray(value)) return value.map(translate).join('、');
    const localized = window.menhBanEngine?.translate?.(String(value));
    return localized && localized !== value ? localized : nameFor[value] || value;
  }
  function ready() {
    const ok = Boolean(window.menhBanEngine?.generateChart);
    engineNote.hidden = ok;
    return ok;
  }
  function escapeHTML(value) {
    return String(value ?? '').replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  }
  function showToast(message) {
    const toast = $('#toast'); toast.textContent = message; toast.classList.add('visible');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('visible'), 2600);
  }
  function setError(message) { formError.textContent = message; formError.hidden = !message; }
  function titleCaseName(palace) { return translate(palace?.name || '').replace(/宫/g,'') || 'Cung'; }
  function getStarList(palace) { return palace?.stars || []; }
  function makeChart(input) {
    const engine = window.menhBanEngine;
    if (!engine) throw new Error('Engine chưa sẵn sàng. Hãy tải lại trang khi có kết nối mạng.');
    const [year,month,day] = input.iso.split('-').map(Number);
    const [clockHour,clockMinute] = input.clockTime.split(':').map(Number);
    const longitude = input.longitude === '' ? undefined : Number(input.longitude);
    const solar = engine.calculateTrueSolarTime({year,month,day,clockHour,clockMinute,...(longitude === undefined ? {} : {longitude,utcOffsetMinutes:420})});
    if (!solar.dateValid) throw new Error('Ngày sinh không hợp lệ. Hãy kiểm tra lại ngày, tháng và năm.');
    const dateOffset = engine.resolveZiweiDayOffset(solar);
    const birthDate = engine.shiftGregorianDate({year,month,day},dateOffset);
    const chart = engine.generateChart({
      ...birthDate,hour:solar.branch,gender:input.gender,name:input.name || undefined,
      city:input.city || undefined,longitude,
      origInput:{year,month,day,clockHour,clockMinute}
    });
    chart.ui = {...input,solar,dateOffset};
    return chart;
  }
  function renderStars(stars) {
    if (!stars.length) return '<span class="star secondary">Vô chính diệu</span>';
    return stars.slice(0,6).map((star) => {
      const siHua = star.siHua ? translate(star.siHua) : '';
      const kind = star.type === 'major' ? 'major' : 'secondary';
      return `<span class="star ${kind} ${siHua ? 'mutagen' : ''}">${escapeHTML(translate(star.name))}${siHua ? `<span class="mutagen-mark">${escapeHTML(siHua)}</span>` : ''}</span>`;
    }).join('');
  }
  function renderBoard(chart) {
    const palaceMap = new Map(chart.palaces.map((palace) => [branches[palace.branch],palace]));
    const board = $('#chartBoard');
    const palaceCards = Object.keys(branchCoord).map((branch) => {
      const palace = palaceMap.get(branch); if (!palace) return '';
      const isMing = palace.isMingGong || palace.branch === chart.mingGongBranch;
      const isBody = palace.isShenGong || palace.branch === chart.shenGongBranch;
      const stars = getStarList(palace);
      const major = stars.filter((star) => star.type === 'major').slice(0,2);
      const others = stars.filter((star) => !major.includes(star)).slice(0,3);
      const age = palace.daXianAge;
      return `<button class="palace-cell ${isMing ? 'ming' : ''}" data-branch="${branch}" aria-label="Cung ${escapeHTML(titleCaseName(palace))}, ${branch}">
        <span class="palace-coord">${escapeHTML(stems[palace.stem] || '')}${branch}</span><span class="palace-name">${isMing ? 'MỆNH' : escapeHTML(titleCaseName(palace).toLocaleUpperCase('vi-VN'))}${isBody ? ' · THÂN' : ''}</span>
        <span class="palace-stars">${renderStars([...major,...others])}</span><span class="palace-meta"><span>${palace.isCurrentDaXian ? 'Đại hạn hiện tại' : ''}</span><span>${age ? `${age[0]}–${age[1]} tuổi` : ''}</span></span></button>`;
    }).join('');
    const pillars = chart.lunarInfo.fourPillars || [];
    board.innerHTML = `${palaceCards}<div class="chart-center"><div class="center-seal">命</div><div class="center-title">${escapeHTML(chart.birthInfo.name || 'Bản mệnh')}</div><div class="center-sub">${escapeHTML(pillars.join(' · '))}</div><div class="center-facts"><span class="fact-chip">${escapeHTML(translate(chart.wuxingJuName))}</span><span class="fact-chip">Mệnh chủ ${escapeHTML(translate(chart.mingZhu))}</span><span class="fact-chip">Thân chủ ${escapeHTML(translate(chart.shenZhu))}</span></div></div>`;
    const b = chart.birthInfo;
    const shownDate = new Date(`${chart.ui.iso}T12:00:00`);
    $('#chartTitle').textContent = b.name ? `Lá số · ${b.name}` : 'Lá số của bạn';
    $('#chartMeta').textContent = `${shownDate.toLocaleDateString('vi-VN',{day:'2-digit',month:'long',year:'numeric'})} · ${chart.ui.clockTime} · ${hourNames[b.hour]} ${hourRanges[b.hour]} · ${b.gender === 'female' ? 'Nữ' : 'Nam'}${b.city ? ` · ${b.city}` : ''}${chart.ui.dateOffset ? ' · ngày Tý đã hiệu chỉnh' : ''}`;
    $('#chartDateLabel').textContent = `${String(b.day).padStart(2,'0')}.${String(b.month).padStart(2,'0')}.${b.year} · ${hourNames[b.hour]}`;
    $$('.palace-cell',board).forEach((cell) => cell.addEventListener('click',() => selectPalace(chart,cell.dataset.branch,cell)));
    const soul = chart.palaces.find((palace) => palace.isMingGong || palace.branch === chart.mingGongBranch);
    const soulBranch = soul ? branches[soul.branch] : '';
    if (soul) selectPalace(chart,soulBranch,$(`.palace-cell[data-branch="${soulBranch}"]`,board));
    renderInsight(chart,activeTab);
    chartSection.hidden = false;
  }
  function selectPalace(chart, branch, element) {
    $$('.palace-cell').forEach((cell) => cell.classList.toggle('selected',cell === element));
    const palace = chart.palaces.find((item) => branches[item.branch] === branch); if (!palace) return;
    const stars = getStarList(palace);
    const isBody = palace.isShenGong || palace.branch === chart.shenGongBranch;
    const age = palace.daXianAge;
    $('#detailName').textContent = `Cung ${titleCaseName(palace)}${isBody ? ' · Thân cư' : ''}`;
    $('#detailSub').textContent = `${stems[palace.stem]}${branch}${age ? ` · Đại hạn ${age[0]}–${age[1]} tuổi` : ''}${palace.isCurrentDaXian ? ' · Đại hạn hiện tại' : ''}`;
    $('#detailStars').innerHTML = stars.length ? stars.map((star) => {
      const hua = star.siHua ? translate(star.siHua) : '';
      return `<span class="detail-star ${hua ? 'mutagen' : ''}">${escapeHTML(translate(star.name))}${star.brightnessRaw ? ` · ${escapeHTML(translate(star.brightnessRaw))}` : ''}${hua ? ` · ${escapeHTML(hua)}` : ''}</span>`;
    }).join('') : '<span class="detail-star">Vô chính diệu</span>';
  }
  function getPalace(chart,name) { return chart.palaces.find((palace) => titleCaseName(palace) === name); }
  function insightText(chart,id) {
    const target = tabs.find((tab) => tab.id === id) || tabs[0];
    const palace = getPalace(chart,target.name) || getPalace(chart,'Mệnh');
    const major = getStarList(palace).filter((star) => star.type === 'major').map((star) => translate(star.name));
    const label = titleCaseName(palace);
    const stars = major.length ? `<strong>${escapeHTML(major.join(' và '))}</strong>` : '<strong>vô chính diệu</strong>';
    const starReflection = major.length
      ? major.map((name) => starNotes[name] ? `${escapeHTML(name)} ${starNotes[name]}` : '').filter(Boolean).join(' ')
      : 'Cung vô chính diệu thường được xem cùng tam phương tứ chính và những cung liên hệ; riêng cung này chưa đủ để luận đoán.';
    const start = id === 'career' ? 'Cung Quan Lộc gợi mở cách bạn phát triển năng lực và tạo giá trị trong công việc.'
      : id === 'wealth' ? 'Cung Tài Bạch là góc nhìn biểu tượng về thói quen tích lũy và cách bạn sử dụng nguồn lực.'
      : id === 'love' ? 'Cung Phu Thê mời bạn suy ngẫm về sự đồng hành, giao tiếp và những giá trị được chia sẻ.'
      : id === 'personality' ? 'Cung Mệnh phản chiếu những phẩm chất và cách ứng xử bạn có thể nhận ra trong trải nghiệm của mình.'
      : 'Cung Mệnh là điểm khởi đầu để quan sát khí chất, động lực và những điều bạn xem trọng.';
    return `<p>${start}</p><p>Tại cung <strong>${escapeHTML(label)}</strong> có ${stars}. ${starReflection}</p><p>Hãy xem đây là chất liệu tự suy ngẫm và đối chiếu với trải nghiệm thực tế của bạn, không phải kết luận cố định.</p><div class="insight-callout">“Biết mình để lựa chọn thuận với điều mình muốn vun bồi.”</div>`;
  }
  function renderInsight(chart,id) {
    activeTab = id;
    $('#insightTabs').innerHTML = tabs.map((tab) => `<button class="insight-tab ${tab.id === id ? 'active' : ''}" role="tab" id="tab-${tab.id}" aria-selected="${tab.id === id}" aria-controls="insightCopy" data-tab="${tab.id}">${tab.label}</button>`).join('');
    $$('.insight-tab').forEach((tab) => tab.addEventListener('click',() => renderInsight(chart,tab.dataset.tab)));
    $('#insightCopy').setAttribute('aria-labelledby',`tab-${id}`);
    $('#insightCopy').innerHTML = insightText(chart,id);
  }
  function getSaved() { try { return JSON.parse(localStorage.getItem('menh-ban:charts') || '[]'); } catch { return []; } }
  function setSaved(charts) {
    try { localStorage.setItem('menh-ban:charts',JSON.stringify(charts)); } catch { showToast('Không thể lưu. Bộ nhớ trình duyệt có thể đã đầy.'); }
    renderSaved();
  }
  function renderSaved() {
    const charts = getSaved(), list = $('#savedList');
    $('#savedCount').textContent = String(charts.length);
    $('#savedTotal').textContent = `${charts.length} hồ sơ`;
    if (!charts.length) { list.innerHTML = '<div class="saved-empty"><span>冊</span><p>Lá số bạn lưu sẽ xuất hiện ở đây.</p></div>'; return; }
    list.innerHTML = charts.map((chart,index) => `<article class="saved-card"><span class="saved-card-mark">命</span><div class="saved-card-copy"><strong>${escapeHTML(chart.name || 'Lá số của tôi')}</strong><span>${escapeHTML(chart.iso.split('-').reverse().join('/'))} · ${escapeHTML(chart.clockTime)} · ${chart.gender === 'female' ? 'Nữ' : 'Nam'} · ${escapeHTML(chart.city || 'Không hiệu chỉnh')}</span></div><div class="saved-card-actions"><button data-load="${index}">Mở lá số</button><button class="delete-button" data-delete="${index}" aria-label="Xóa ${escapeHTML(chart.name || 'lá số')}">Xóa</button></div></article>`).join('');
    $$('[data-load]',list).forEach((button) => button.addEventListener('click',() => {
      if (!ready()) { showToast('Engine chưa sẵn sàng. Tải lại trang khi có kết nối mạng.'); return; }
      try { activeChart = makeChart(getSaved()[Number(button.dataset.load)]); renderBoard(activeChart); chartSection.scrollIntoView({behavior:'smooth',block:'start'}); }
      catch (error) { showToast(error.message || 'Không mở được lá số này.'); }
    }));
    $$('[data-delete]',list).forEach((button) => button.addEventListener('click',() => {
      const items = getSaved(); items.splice(Number(button.dataset.delete),1); setSaved(items); showToast('Đã xóa hồ sơ trên thiết bị.');
    }));
  }
  function readInput() {
    const iso = dateInput.value, clockTime = timeInput.value;
    const gender = $('input[name="gender"]:checked')?.value;
    if (!iso) throw new Error('Vui lòng chọn ngày sinh.');
    if (!clockTime) throw new Error('Vui lòng nhập giờ sinh.');
    const [year,month,day] = iso.split('-').map(Number);
    const probe = new Date(year,month-1,day);
    if (probe.getFullYear() !== year || probe.getMonth() !== month-1 || probe.getDate() !== day) throw new Error('Ngày sinh không hợp lệ.');
    if (year < 1900 || year > new Date().getFullYear()) throw new Error('Năm sinh cần nằm trong khoảng từ 1900 đến hiện tại.');
    const option = citySelect.selectedOptions[0];
    return {iso,clockTime,gender,name:$('#personName').value.trim(),longitude:citySelect.value,city:citySelect.value ? option.textContent : ''};
  }
  form.addEventListener('submit',(event) => {
    event.preventDefault(); setError('');
    try {
      const input = readInput();
      if (!ready()) { engineNote.hidden = false; engineNote.scrollIntoView({behavior:'smooth',block:'center'}); return; }
      activeChart = makeChart(input); renderBoard(activeChart); chartSection.scrollIntoView({behavior:'smooth',block:'start'});
    } catch (error) { setError(error.message || 'Không thể lập lá số. Vui lòng kiểm tra lại thông tin.'); }
  });
  $('#saveButton').addEventListener('click',() => {
    if (!activeChart) return;
    const ui = activeChart.ui, charts = getSaved();
    if (charts.some((item) => item.iso === ui.iso && item.clockTime === ui.clockTime && item.gender === ui.gender && item.name === ui.name && item.longitude === ui.longitude)) { showToast('Lá số này đã có trong hồ sơ đã lưu.'); return; }
    charts.unshift({...ui,savedAt:new Date().toISOString()}); setSaved(charts); showToast('Đã lưu riêng trên thiết bị này.');
  });
  $('#printButton').addEventListener('click',() => window.print());
  $('#downloadButton').addEventListener('click',() => {
    if (!activeChart) return;
    const chart = activeChart, b = chart.birthInfo;
    const xml = (value) => String(value ?? '').replace(/[&<>"']/g,(c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
    const palaceMap = new Map(chart.palaces.map((palace) => [branches[palace.branch],palace]));
    const cells = Object.entries(branchCoord).map(([branch,coord]) => {
      const palace = palaceMap.get(branch); if (!palace) return '';
      const [row,column] = coord.split('/').map(Number), x=(column-1)*300, y=(row-1)*250;
      const isMing = palace.branch === chart.mingGongBranch, isBody = palace.branch === chart.shenGongBranch;
      const stars = getStarList(palace).slice(0,7);
      const lines = stars.map((star,index) => `<text x="${x+20}" y="${y+78+index*29}" font-size="${index<2?21:17}" fill="${star.siHua?'#a63b2d':index<2?'#263e32':'#776b59'}">${xml(translate(star.name))}${star.siHua?` · ${xml(translate(star.siHua))}`:''}</text>`).join('');
      return `<g><rect x="${x}" y="${y}" width="300" height="250" fill="${isMing?'#eaf0e8':'#fbfaf5'}" stroke="#d8d4c5" stroke-width="2"/><text x="${x+20}" y="${y+34}" font-size="13" fill="#9d8b62">${xml(stems[palace.stem])}${branch}</text><text x="${x+20}" y="${y+57}" font-size="15" font-family="Arial,sans-serif" font-weight="600" fill="${isMing?'#49624d':'#70766c'}">${xml(titleCaseName(palace).toLocaleUpperCase('vi-VN'))}${isBody?' · THÂN':''}</text>${lines||`<text x="${x+20}" y="${y+91}" font-size="16" fill="#8a7760">Vô chính diệu</text>`}<text x="${x+20}" y="${y+231}" font-size="12" fill="#979184">${palace.isCurrentDaXian?'Đại hạn hiện tại':''}</text></g>`;
    }).join('');
    const date=new Date(`${chart.ui.iso}T12:00:00`).toLocaleDateString('vi-VN',{day:'2-digit',month:'long',year:'numeric'});
    const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="1000" viewBox="0 0 1200 1000"><rect width="1200" height="1000" fill="#fffefb"/>${cells}<rect x="300" y="250" width="600" height="500" fill="#f7f5ee" stroke="#d8d4c5" stroke-width="2"/><circle cx="600" cy="500" r="196" fill="none" stroke="#e6e0d1" stroke-width="2"/><circle cx="600" cy="500" r="166" fill="none" stroke="#e0dacb" stroke-width="1" stroke-dasharray="3 8"/><text x="600" y="430" text-anchor="middle" font-size="18" letter-spacing="4" fill="#9d8b62">MỆNH BÀN · TỬ VI ĐẨU SỐ</text><text x="600" y="488" text-anchor="middle" font-size="35" fill="#283a2c">${xml(b.name||'Bản mệnh')}</text><text x="600" y="530" text-anchor="middle" font-size="18" fill="#797d70">${xml(date)} · ${xml(hourRanges[b.hour])} · ${b.gender==='female'?'Nữ':'Nam'}</text><text x="600" y="574" text-anchor="middle" font-size="17" fill="#59634f">${xml(translate(chart.wuxingJuName))}　Mệnh chủ ${xml(translate(chart.mingZhu))}　Thân chủ ${xml(translate(chart.shenZhu))}</text><text x="600" y="980" text-anchor="middle" font-size="12" fill="#898575">Mệnh Bàn · Nội dung chiêm nghiệm mang tính tham khảo</text></svg>`;
    const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml;charset=utf-8'})), image=new Image();
    image.onload=()=>{const canvas=document.createElement('canvas');canvas.width=2400;canvas.height=2000;const ctx=canvas.getContext('2d');ctx.scale(2,2);ctx.drawImage(image,0,0,1200,1000);URL.revokeObjectURL(url);canvas.toBlob((png)=>{if(!png){showToast('Không thể tạo ảnh. Hãy dùng In / Lưu PDF.');return;}const a=document.createElement('a');a.href=URL.createObjectURL(png);a.download=`menh-ban-${chart.ui.iso}.png`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);});};
    image.onerror=()=>{URL.revokeObjectURL(url);showToast('Không thể xuất ảnh. Hãy dùng In / Lưu PDF.');};image.src=url;
  });
  $('#retryButton').addEventListener('click',() => location.reload());
  $('#menuButton').addEventListener('click',(event) => {const open=$('#sidebar').classList.toggle('open');event.currentTarget.setAttribute('aria-expanded',String(open));});
  $$('.nav-item').forEach((item) => item.addEventListener('click',() => {
    $$('.nav-item').forEach((nav) => nav.classList.toggle('active',nav===item));
    if (innerWidth<=850) {$('#sidebar').classList.remove('open');$('#menuButton').setAttribute('aria-expanded','false');}
  }));
  const today=new Date();dateInput.max=`${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;dateInput.value='1994-08-18';
  setTimeout(ready,100);renderSaved();
})();
