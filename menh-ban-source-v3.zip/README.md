# Mệnh Bàn

Web tiếng Việt để lập và chiêm nghiệm lá số Tử Vi Đẩu Số. Giao diện lấy cảm hứng từ giấy dó, la bàn và dấu son trong mỹ học phương Đông; lá số được tính ngay trên trình duyệt.

## Chạy ở máy cá nhân

Yêu cầu Node.js 22 trở lên.

```bash
npm ci
npm run dev
```

Mở địa chỉ localhost mà Next.js hiển thị. Tạo bản tĩnh để đưa lên host miễn phí:

```bash
npm run build
```

Thư mục tĩnh được xuất ra `out/`.

## Deploy miễn phí bằng GitHub Pages

Repo có sẵn workflow tại `.github/workflows/pages.yml` để build và xuất bản tự động.

1. Tạo một **repository công khai** trên GitHub Free và đẩy nội dung thư mục này lên nhánh `main`.
2. Trong repo, mở **Settings → Pages** và chọn **GitHub Actions** làm nguồn xuất bản.
3. Push lên `main` hoặc chạy workflow **Build and deploy Mệnh Bàn** trong tab Actions.
4. GitHub Pages sẽ hiện địa chỉ website trong phần **Settings → Pages** sau khi workflow hoàn tất.

Workflow tự xử lý đường dẫn cho cả project page dạng `https://tai-khoan.github.io/ten-repo/` và user page dạng `https://tai-khoan.github.io/`. GitHub Pages miễn phí cho repo công khai trên GitHub Free. Xem [tài liệu GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages) và [hướng dẫn xuất static của Next.js](https://nextjs.org/docs/app/guides/static-exports).

## Tính năng

- Nhập ngày Dương lịch, giờ và nơi sinh; hiệu chỉnh chân thái dương thời gian theo engine repo.
- Tự xử lý giờ Tý khuya và ngày sinh có thể cần chuyển ngày.
- Xem đủ mười hai cung, sao, độ sáng, Tứ Hóa, cung Thân, đại hạn, Mệnh chủ, Thân chủ và ngũ hành cục.
- Chọn cung để xem luận giải tiếng Việt theo sao chính ở sáu chủ đề: tổng quan, tính cách, sự nghiệp, tài lộc, tình duyên và sức khỏe.
- Lưu, mở và xóa lá số cục bộ; in hoặc lưu PDF; tải ảnh lá số PNG.
- Giao diện thích ứng với điện thoại; toàn bộ thao tác và nội dung giao diện bằng tiếng Việt.

## Riêng tư và giới hạn

Không có tài khoản, backend, API key hoặc dịch vụ AI. Dữ liệu sinh chỉ được gửi vào engine chạy trong trình duyệt; hồ sơ chỉ lưu trong local storage của thiết bị hiện tại. Xóa dữ liệu web của trình duyệt sẽ xóa hồ sơ đã lưu. Google Fonts là tuỳ chọn giao diện; nếu không tải được, trình duyệt dùng font dự phòng. Lần deploy GitHub Pages đầu tiên cần một repo GitHub công khai do bạn quản lý.

Luận giải theo sao được Việt hóa, biên soạn theo phần `StarDetailPanel` trong repo nguồn; đây là diễn giải văn hóa tổng quát, không phải dự đoán chắc chắn hay lời khuyên y tế, pháp lý, tài chính. Repo nguồn cũng phát hành riêng bộ dữ liệu luận giải 13 chủ đề (v4.0); bộ dữ liệu đó không được nhúng vào bản GitHub Pages này.

## Ghi công và giấy phép

Engine Tử Vi và nội dung tham khảo sao được lấy từ [Renhuai123/ziwei-doushu](https://github.com/Renhuai123/ziwei-doushu), giấy phép mã nguồn [MIT](./UPSTREAM-LICENSE-MIT). Dữ liệu luận giải v4.0 không được nhúng vào trang; khi dùng dữ liệu này cần kèm ghi công theo [DATASET-LICENSE](https://github.com/Renhuai123/ziwei-doushu/blob/main/DATASET-LICENSE). Trích dẫn nguyên văn Ni Hải Hạ có giấy phép riêng và không được đưa vào trang.
