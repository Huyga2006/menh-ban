/** @type {import('next').NextConfig} */
const repositoryName = process.env.GITHUB_REPOSITORY?.split('/')[1];
const isProjectPage = process.env.GITHUB_ACTIONS === 'true'
  && repositoryName
  && !repositoryName.endsWith('.github.io');
const basePath = isProjectPage ? `/${repositoryName}` : '';

const nextConfig = {
  output: 'export',
  trailingSlash: true,
  basePath,
  transpilePackages: ['lunar-javascript'],
  turbopack: { root: __dirname },
};
module.exports = nextConfig;
