import { readFileSync } from 'node:fs';
import path from 'node:path';
import EngineBridge from './EngineBridge';

const source = readFileSync(path.join(process.cwd(), 'public', 'app-shell.html'), 'utf8');
const body = source.match(/<body[^>]*>([\s\S]*?)<\/body>/i)?.[1] ?? '';
const shell = body
  .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
  .replace(/<link\b[^>]*>/gi, '')
  .replace(/<title>[\s\S]*?<\/title>/gi, '');

export default function Home() {
  return <><div dangerouslySetInnerHTML={{ __html: shell }} /><EngineBridge /></>;
}
