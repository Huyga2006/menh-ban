import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Mệnh Bàn — Tử Vi Đẩu Số',
  description: 'Lập và chiêm nghiệm lá số Tử Vi Đẩu Số bằng tiếng Việt. Riêng tư trên thiết bị, miễn phí.',
  applicationName: 'Mệnh Bàn',
};

export const viewport: Viewport = { themeColor: '#15251f' };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="vi"><body>{children}</body></html>;
}
