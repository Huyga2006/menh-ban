(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const form = $('#birthForm');
  const dateInput = $('#birthDate');
  const timeInput = $('#birthTime');
  const citySelect = $('#birthCity');
  const chartSection = $('#chartSection');
  const formError = $('#formError');
  const engineNote = $('#engineNote');
  const branches = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
  const stems = ['甲','乙','丙','丁','戊','己','庚','辛','壬','癸'];
  const branchCoord = {'巳':'1/1','午':'1/2','未':'1/3','申':'1/4','酉':'2/4','戌':'3/4','亥':'4/4','子':'4/3','丑':'4/2','寅':'4/1','卯':'3/1','辰':'2/1'};
  const hourNames = ['Tý','Sửu','Dần','Mão','Thìn','Tỵ','Ngọ','Mùi','Thân','Dậu','Tuất','Hợi'];
  const hourRanges = ['23:00–01:00','01:00–03:00','03:00–05:00','05:00–07:00','07:00–09:00','09:00–11:00','11:00–13:00','13:00–15:00','15:00–17:00','17:00–19:00','19:00–21:00','21:00–23:00'];
  const nameFor = {
    '命宫':'Mệnh','兄弟宫':'Huynh Đệ','夫妻宫':'Phu Thê','子女宫':'Tử Tức','财帛宫':'Tài Bạch','疾厄宫':'Tật Ách','迁移宫':'Thiên Di','仆役宫':'Nô Bộc','交友宫':'Nô Bộc','官禄宫':'Quan Lộc','田宅宫':'Điền Trạch','福德宫':'Phúc Đức','父母宫':'Phụ Mẫu',
    '紫微':'Tử Vi','天机':'Thiên Cơ','太阳':'Thái Dương','武曲':'Vũ Khúc','天同':'Thiên Đồng','廉贞':'Liêm Trinh','天府':'Thiên Phủ','太阴':'Thái Âm','贪狼':'Tham Lang','巨门':'Cự Môn','天相':'Thiên Tướng','天梁':'Thiên Lương','七杀':'Thất Sát','破军':'Phá Quân',
    '左辅':'Tả Phù','右弼':'Hữu Bật','文昌':'Văn Xương','文曲':'Văn Khúc','天魁':'Thiên Khôi','天钺':'Thiên Việt','禄存':'Lộc Tồn','擎羊':'Kình Dương','陀罗':'Đà La','火星':'Hỏa Tinh','铃星':'Linh Tinh','地空':'Địa Không','地劫':'Địa Kiếp','天马':'Thiên Mã','红鸾':'Hồng Loan','天喜':'Thiên Hỷ','天姚':'Thiên Diêu','天刑':'Thiên Hình','天哭':'Thiên Khốc','天虚':'Thiên Hư',
    '禄':'Lộc','权':'Quyền','科':'Khoa','忌':'Kỵ','庙':'Miếu','旺':'Vượng','得':'Đắc','利':'Lợi','平':'Bình','不':'Bất','闲':'Nhàn','陷':'Hãm','地':'Địa',
    '金四局':'Kim Tứ Cục','木三局':'Mộc Tam Cục','水二局':'Thủy Nhị Cục','火六局':'Hỏa Lục Cục','土五局':'Thổ Ngũ Cục'
  };
  const tabs = [
    {id:'overview',label:'Tổng quan',name:'Mệnh'},
    {id:'career',label:'Sự nghiệp',name:'Quan Lộc'},
    {id:'wealth',label:'Tài lộc',name:'Tài Bạch'},
    {id:'love',label:'Tình duyên',name:'Phu Thê'},
    {id:'personality',label:'Tính cách',name:'Mệnh'},
    {id:'health',label:'Sức khỏe',name:'Tật Ách'}
  ];
  // Bản Việt hóa, biên soạn theo STAR_DETAIL trong repo gốc; là diễn giải văn hóa, không phải dự báo chắc chắn.
  const starReadings = {
    '紫微': {overview:'Tử Vi thường được ví với vai trò chủ quản: thiên về tổ chức, trách nhiệm và mong muốn tự quyết. Khi xét cách cục cần nhìn thêm Tả Phù, Hữu Bật, các sao đồng cung và tam phương tứ chính.',personality:'Khí chất tự trọng, thích chủ động và có xu hướng đứng ra sắp xếp công việc. Mặt cần quan sát là đôi khi khó nhờ cậy người khác hoặc muốn tự mình quyết định.',career:'Hợp môi trường cần điều phối, quản lý hoặc chịu trách nhiệm chung. Năng lực lãnh đạo phát huy tốt hơn khi biết trao quyền và tiếp nhận phản hồi.',love:'Trong quan hệ có thể coi trọng sự tôn trọng và vị thế của mỗi người. Giao tiếp mềm mại, chia sẻ việc quyết định giúp tránh cảm giác xa cách.',wealth:'Thiên về giữ nền tảng và quản lý nguồn lực hơn là mạo hiểm. Cần xem thêm cung Tài Bạch, Điền Trạch và các sao hội chiếu trước khi luận tài vận.',health:'Theo biểu tượng ngũ hành truyền thống, Tử Vi thuộc Thổ. Đây không phải đánh giá y khoa; sức khỏe nên dựa vào thăm khám và tư vấn chuyên môn.'},
    '天机': {overview:'Thiên Cơ tượng trưng cho trí mưu, sự linh hoạt và khả năng tìm phương án. Tính biến động của sao khiến toàn cách cục và trạng thái miếu, hãm có ý nghĩa quan trọng.',personality:'Nhanh trí, ham học và thích phân tích nhiều khả năng. Mặt trái có thể là đổi ý nhiều hoặc suy nghĩ quá lâu trước khi chọn.',career:'Hợp công việc nghiên cứu, kỹ thuật, hoạch định, tư vấn hoặc giải quyết vấn đề. Nên rèn khả năng hoàn tất kế hoạch thay vì chỉ tiếp tục tối ưu.',love:'Cần sự trao đổi trí tuệ và cảm giác được lắng nghe. Nói rõ nhu cầu, tránh suy diễn thay đối phương có thể giúp quan hệ ổn định hơn.',wealth:'Nguồn lực thường gắn với kỹ năng và tri thức. Lập kế hoạch tiết kiệm cụ thể sẽ hữu ích nếu thu nhập hoặc định hướng công việc thay đổi.',health:'Theo ngũ hành truyền thống, Thiên Cơ thuộc Mộc. Đây chỉ là biểu tượng văn hóa, không dùng để chẩn đoán cơ thể hay bệnh lý.'},
    '太阳': {overview:'Thái Dương gợi hình ảnh ánh sáng, sự chủ động và tinh thần hướng ra cộng đồng. Ý nghĩa thay đổi theo vị trí, giới tính theo phép luận cổ và các sao hội chiếu.',personality:'Thường được gắn với sự rộng rãi, thẳng thắn và mong muốn đóng góp. Cần để ý việc nhận quá nhiều trách nhiệm hoặc quá chú trọng sự công nhận.',career:'Có thể hợp giáo dục, truyền thông, dịch vụ công, quản lý hoặc công việc cần xuất hiện trước tập thể. Nhịp làm việc bền vững quan trọng hơn cố gắng quá sức.',love:'Sự quan tâm thường thể hiện qua hành động và trách nhiệm. Chủ động lắng nghe cảm xúc của người kia giúp cân bằng xu hướng tập trung vào việc lớn.',wealth:'Quan niệm truyền thống thường liên hệ tài lộc với lao động và sự hào sảng. Muốn đánh giá cụ thể cần xét thêm cung Tài Bạch cùng Tứ Hóa.',health:'Theo ngũ hành truyền thống, Thái Dương thuộc Hỏa. Nội dung này không phải lời khuyên hay chẩn đoán y tế.'},
    '武曲': {overview:'Vũ Khúc là sao thiên về tài chính, tính thực tế và sự quyết đoán trong truyền thống Tử Vi. Cần phối hợp với cung vị, Tứ Hóa và các sao đồng cung.',personality:'Thường gợi tính kỷ luật, thẳng thắn và chú trọng kết quả. Bài học có thể là diễn đạt sự quan tâm mềm hơn và linh hoạt khi kế hoạch đổi khác.',career:'Hợp các công việc đòi hỏi quản trị nguồn lực, tài chính, kỹ thuật, vận hành hoặc quyết định rõ ràng. Kết hợp sức bền với hợp tác sẽ giảm sự cứng nhắc.',love:'Có xu hướng thể hiện tình cảm bằng trách nhiệm và việc làm cụ thể. Chia sẻ cảm xúc bằng lời giúp đối phương không phải tự đoán ý.',wealth:'Có thiên hướng coi trọng quản lý tiền bạc và tích lũy. Không nên xem một sao đơn lẻ là bảo đảm giàu có; hãy xét toàn bộ cung Tài Bạch và thói quen thực tế.',health:'Theo ngũ hành truyền thống, Vũ Khúc thuộc Kim. Lá số không thể thay thế khám sức khỏe hoặc đánh giá chuyên môn.'},
    '天同': {overview:'Thiên Đồng gợi sự an hòa, thích nghi và mong muốn tận hưởng cuộc sống. Khi phối cùng Thiên Lương hoặc các sao khác, sắc thái luận đoán sẽ thay đổi.',personality:'Dễ cảm thông, hòa nhã và coi trọng môi trường dễ chịu. Có thể cần chủ động hơn khi gặp cạnh tranh hoặc phải quyết định khó.',career:'Hợp môi trường dịch vụ, chăm sóc, sáng tạo hoặc làm việc nhóm thân thiện. Mục tiêu rõ ràng giúp giữ nhịp tiến triển lâu dài.',love:'Coi trọng sự dịu dàng và cảm giác an toàn. Nói rõ điều mình mong đợi sẽ tốt hơn việc né tránh bất đồng để giữ hòa khí.',wealth:'Thường thiên về sự ổn định hơn là đầu cơ. Kế hoạch tiết kiệm đều đặn có thể phù hợp hơn việc chờ vận may.',health:'Theo ngũ hành truyền thống, Thiên Đồng thuộc Thủy. Chỉ xem như ngôn ngữ biểu tượng, không suy ra tình trạng sức khỏe.'},
    '廉贞': {overview:'Liêm Trinh thường gắn với cá tính rõ nét, sức hút và nhu cầu về nguyên tắc. Truyền thống luận sao này rất coi trọng Tứ Hóa cùng các sao đi kèm.',personality:'Có tiêu chuẩn riêng và khả năng tạo dấu ấn cá nhân. Cần phân biệt sự kiên định với cố chấp, nhất là khi cảm xúc đang mạnh.',career:'Có thể phát huy trong lĩnh vực sáng tạo, pháp lý, hành chính hoặc công việc cần nguyên tắc. Minh bạch trong quyết định giúp năng lực được tin cậy.',love:'Tình cảm thường sâu và mạnh, đôi khi dễ nảy sinh kỳ vọng cao. Thỏa thuận ranh giới và nói chuyện thẳng thắn có ích cho cả hai phía.',wealth:'Có thể gắn với tài năng cá nhân và những lựa chọn nhiều biến động. Nên quản lý rủi ro thực tế, không dựa vào lá số để quyết định đầu tư.',health:'Theo ngũ hành truyền thống, Liêm Trinh thuộc Hỏa. Phần luận số không xác định bệnh tật hoặc nguy cơ y khoa.'},
    '天府': {overview:'Thiên Phủ được ví như kho tàng, tượng trưng cho sự ổn định, gìn giữ và điều phối nguồn lực. Tử Vi đồng cung hoặc hội chiếu có thể làm đổi trọng tâm luận đoán.',personality:'Điềm tĩnh, thực tế và coi trọng nền nếp. Cần cân bằng sự thận trọng với khả năng đón nhận thay đổi cần thiết.',career:'Hợp quản trị, tài chính, vận hành, hành chính hoặc lĩnh vực xây dựng nền tảng dài hạn. Sự ổn định sẽ mạnh hơn khi có mục tiêu phát triển cụ thể.',love:'Thường coi trọng lòng tin, sự ổn định và chăm lo gia đình. Nên bày tỏ tình cảm rõ ràng thay vì chỉ tập trung vào trách nhiệm.',wealth:'Có khuynh hướng giữ gìn và tích lũy. Việc quản lý ngân sách và phân tán rủi ro vẫn quan trọng hơn một dấu hiệu đơn lẻ trên lá số.',health:'Theo ngũ hành truyền thống, Thiên Phủ thuộc Thổ. Đây không phải thông tin y tế hay khuyến nghị điều trị.'},
    '太阴': {overview:'Thái Âm tượng trưng cho chiều sâu cảm xúc, sự tinh tế và tài nguyên tích lũy trong cách luận truyền thống. Vị trí sáng tối và các sao đi kèm ảnh hưởng đáng kể.',personality:'Nhạy cảm, quan sát tốt và thường suy nghĩ sâu. Dành thời gian nghỉ ngơi và diễn đạt cảm xúc giúp tránh giữ mọi điều trong lòng.',career:'Có thể hợp tài chính, giáo dục, nghệ thuật, nghiên cứu hoặc công việc cần sự tỉ mỉ. Môi trường tôn trọng chiều sâu và nhịp làm việc ổn định thường dễ phát huy.',love:'Coi trọng sự đồng cảm và cảm giác an toàn. Nói ra nhu cầu thay vì chờ người kia tự nhận biết sẽ giúp quan hệ rõ ràng hơn.',wealth:'Truyền thống liên hệ Thái Âm với tích lũy và tài sản. Muốn luận cụ thể vẫn cần xem cung Tài Bạch, Điền Trạch và các yếu tố khác.',health:'Theo ngũ hành truyền thống, Thái Âm thuộc Thủy. Không dùng cách quy chiếu này để kết luận sức khỏe.'},
    '贪狼': {overview:'Tham Lang gắn với tính ham trải nghiệm, giao tiếp và nhiều tài năng. Cách cục, Tứ Hóa và các sao hội chiếu quyết định sắc thái cụ thể.',personality:'Tò mò, hoạt bát và dễ tìm thấy điều mới để theo đuổi. Có thể cần chọn ưu tiên để năng lượng không bị chia nhỏ.',career:'Hợp công việc cần giao tiếp, sáng tạo, bán hàng, nghệ thuật hoặc xây dựng quan hệ. Kỷ luật cá nhân giúp biến nhiều sở thích thành kỹ năng bền vững.',love:'Có sức hút và thích sự mới mẻ; sự tin cậy phụ thuộc vào cách hai người thống nhất ranh giới. Giao tiếp trung thực có vai trò quan trọng.',wealth:'Cơ hội có thể đến qua mạng lưới và năng lực cá nhân. Quản lý chi tiêu và tránh quyết định bốc đồng là điều thiết thực.',health:'Theo ngũ hành truyền thống, Tham Lang thuộc Mộc, có pha Thủy trong một số hệ quy chiếu. Không xem đây là chẩn đoán.'},
    '巨门': {overview:'Cự Môn thường gợi khả năng diễn đạt, phản biện và những việc cần làm sáng tỏ. Tứ Hóa và vị trí cung có thể làm thay đổi mặt thuận hoặc khó.',personality:'Có óc phân tích và chú ý đến chi tiết. Lắng nghe trước khi phản biện giúp lời nói trở thành cầu nối thay vì nguồn hiểu lầm.',career:'Có thể phù hợp giảng dạy, luật, tư vấn, thương lượng, truyền thông hoặc công việc dựa trên ngôn từ và chuyên môn.',love:'Giao tiếp là trọng tâm; sự hoài nghi hoặc tranh luận kéo dài có thể làm mệt mỏi. Nên hỏi rõ thay vì mặc định ý của đối phương.',wealth:'Thu nhập có thể liên quan chuyên môn và khả năng trình bày. Thỏa thuận tài chính rõ ràng giúp hạn chế tranh chấp.',health:'Theo ngũ hành truyền thống, Cự Môn thuộc Thủy. Mọi dấu hiệu sức khỏe cần được chuyên gia y tế đánh giá.'},
    '天相': {overview:'Thiên Tướng tượng trưng cho sự hỗ trợ, công bằng và việc điều phối. Liêm Trinh hoặc các sao khác đồng cung sẽ tạo sắc thái riêng.',personality:'Coi trọng phép tắc, sự công tâm và vai trò kết nối. Có thể cần tự quyết nhiều hơn thay vì luôn đợi người khác định hướng.',career:'Hợp hành chính, điều phối, hỗ trợ chuyên môn hoặc những vị trí giữ quy trình vận hành. Năng lực phối hợp là điểm mạnh.',love:'Trung thành, thực tế và coi trọng sự ổn định. Cần chủ động trao đổi mong muốn cá nhân để quan hệ không chỉ xoay quanh bổn phận.',wealth:'Thường thiên về quản lý ổn định và tích lũy từng bước. Hãy đánh giá tài chính dựa trên thu nhập, chi tiêu và kế hoạch cụ thể.',health:'Theo ngũ hành truyền thống, Thiên Tướng thuộc Thủy. Nội dung không thay thế lời khuyên y tế.'},
    '天梁': {overview:'Thiên Lương gắn với sự che chở, kinh nghiệm và lòng nâng đỡ trong cách nhìn cổ điển. Cần xem thêm cung vị và các sao đồng hội để hiểu toàn cục.',personality:'Chín chắn, bao dung và có xu hướng giúp người khác. Giữ ranh giới lành mạnh giúp sự quan tâm không biến thành gánh nặng.',career:'Có thể hợp giáo dục, chăm sóc, tư vấn, pháp lý hoặc công việc phục vụ cộng đồng. Kinh nghiệm tích lũy là lợi thế khi được dùng đúng chỗ.',love:'Coi trọng sự trưởng thành và tin cậy; đôi lúc dễ đảm nhận vai trò chăm sóc quá nhiều. Quan hệ cân bằng cần sự đóng góp từ cả hai.',wealth:'Truyền thống nhấn mạnh sự bền bỉ và hỗ trợ từ kinh nghiệm, không đồng nghĩa tài lộc tự đến. Kế hoạch thực tế vẫn là nền tảng.',health:'Theo ngũ hành truyền thống, Thiên Lương thuộc Thổ. Không thể dùng lá số để chẩn đoán hay trì hoãn điều trị.'},
    '七杀': {overview:'Thất Sát được ví với tính quyết đoán, hành động và khả năng đối diện áp lực. Bộ sao đi kèm đặc biệt quan trọng khi luận tính chất mạnh hay mềm.',personality:'Quyết liệt, độc lập và thích xử lý vấn đề trực tiếp. Kiên nhẫn và trao đổi với người khác giúp hạn chế hành động quá vội.',career:'Có thể phát huy ở vai trò cần quyết định, khai mở hoặc xử lý tình huống khó. Cần xây thói quen đánh giá rủi ro trước khi hành động.',love:'Coi trọng sự thẳng thắn và không gian riêng. Lắng nghe, nhường nhịn đúng lúc giúp giảm cảm giác căng thẳng trong quan hệ.',wealth:'Tượng trưng cho xu hướng chủ động và chấp nhận thử thách, không bảo đảm mức tài vận. Tránh dùng luận số thay cho phân tích tài chính.',health:'Theo ngũ hành truyền thống, Thất Sát thuộc Kim. Lá số không thể tiên đoán tai nạn hay bệnh lý.'},
    '破军': {overview:'Phá Quân tượng trưng cho đổi mới, phá khuôn cũ và làm lại cấu trúc. Truyền thống thường xét kỹ Tứ Hóa cùng toàn bộ cách cục.',personality:'Thích thử hướng mới và không ngại thay đổi. Lập kế hoạch chuyển tiếp giúp giữ lại phần nền tảng hữu ích thay vì thay đổi chỉ vì bứt bối.',career:'Hợp cải tiến, sáng tạo, khởi đầu dự án hoặc môi trường đang chuyển đổi. Cần cân bằng tinh thần tiên phong với khả năng duy trì việc đã bắt đầu.',love:'Cần sự chân thật và không gian để phát triển. Quan hệ bền hơn khi thay đổi được trao đổi trước, không để đối phương bất ngờ.',wealth:'Có thể liên hệ những giai đoạn thay đổi nguồn lực. Quỹ dự phòng và quyết định có tính toán giúp giảm tác động của biến động.',health:'Theo ngũ hành truyền thống, Phá Quân thuộc Thủy. Đây chỉ là diễn giải văn hóa, không phải đánh giá y khoa.'}
  };
  let activeChart = null;
  let activeTab = 'overview';
  let toastTimer;

  function translate(value) {
    if (!value) return '';
    if (Array.isArray(value)) return value.map(translate).join('、');
    const localized = window.menhBanEngine?.translate?.(String(value));
    return localized && localized !== value ? localized : nameFor[value] || value;
  }
  function ready() {
    const ok = Boolean(window.menhBanEngine?.generateChart);
    engineNote.hidden = ok;
    return ok;
  }
  function escapeHTML(value) {
    return String(value ?? '').replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  }
  function showToast(message) {
    const toast = $('#toast'); toast.textContent = message; toast.classList.add('visible');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('visible'), 2600);
  }
  function setError(message) { formError.textContent = message; formError.hidden = !message; }
  function titleCaseName(palace) { return translate(palace?.name || '').replace(/宫/g,'') || 'Cung'; }
  function getStarList(palace) { return palace?.stars || []; }
  function makeChart(input) {
    const engine = window.menhBanEngine;
    if (!engine) throw new Error('Engine chưa sẵn sàng. Hãy tải lại trang khi có kết nối mạng.');
    const [year,month,day] = input.iso.split('-').map(Number);
    const [clockHour,clockMinute] = input.clockTime.split(':').map(Number);
    const longitude = input.longitude === '' ? undefined : Number(input.longitude);
    const solar = engine.calculateTrueSolarTime({year,month,day,clockHour,clockMinute,...(longitude === undefined ? {} : {longitude,utcOffsetMinutes:420})});
    if (!solar.dateValid) throw new Error('Ngày sinh không hợp lệ. Hãy kiểm tra lại ngày, tháng và năm.');
    const dateOffset = engine.resolveZiweiDayOffset(solar);
    const birthDate = engine.shiftGregorianDate({year,month,day},dateOffset);
    const chart = engine.generateChart({
      ...birthDate,hour:solar.branch,gender:input.gender,name:input.name || undefined,
      city:input.city || undefined,longitude,
      origInput:{year,month,day,clockHour,clockMinute}
    });
    chart.ui = {...input,solar,dateOffset};
    return chart;
  }
  function renderStars(stars) {
    if (!stars.length) return '<span class="star secondary">Vô chính diệu</span>';
    return stars.slice(0,6).map((star) => {
      const siHua = star.siHua ? translate(star.siHua) : '';
      const kind = star.type === 'major' ? 'major' : 'secondary';
      return `<span class="star ${kind} ${siHua ? 'mutagen' : ''}">${escapeHTML(translate(star.name))}${siHua ? `<span class="mutagen-mark">${escapeHTML(siHua)}</span>` : ''}</span>`;
    }).join('');
  }
  function renderBoard(chart) {
    const palaceMap = new Map(chart.palaces.map((palace) => [branches[palace.branch],palace]));
    const board = $('#chartBoard');
    const palaceCards = Object.keys(branchCoord).map((branch) => {
      const palace = palaceMap.get(branch); if (!palace) return '';
      const isMing = palace.isMingGong || palace.branch === chart.mingGongBranch;
      const isBody = palace.isShenGong || palace.branch === chart.shenGongBranch;
      const stars = getStarList(palace);
      const major = stars.filter((star) => star.type === 'major').slice(0,2);
      const others = stars.filter((star) => !major.includes(star)).slice(0,3);
      const age = palace.daXianAge;
      return `<button class="palace-cell ${isMing ? 'ming' : ''}" data-branch="${branch}" aria-label="Cung ${escapeHTML(titleCaseName(palace))}, ${branch}">
        <span class="palace-coord">${escapeHTML(stems[palace.stem] || '')}${branch}</span><span class="palace-name">${isMing ? 'MỆNH' : escapeHTML(titleCaseName(palace).toLocaleUpperCase('vi-VN'))}${isBody ? ' · THÂN' : ''}</span>
        <span class="palace-stars">${renderStars([...major,...others])}</span><span class="palace-meta"><span>${palace.isCurrentDaXian ? 'Đại hạn hiện tại' : ''}</span><span>${age ? `${age[0]}–${age[1]} tuổi` : ''}</span></span></button>`;
    }).join('');
    const pillars = chart.lunarInfo.fourPillars || [];
    board.innerHTML = `${palaceCards}<div class="chart-center"><div class="center-seal">命</div><div class="center-title">${escapeHTML(chart.birthInfo.name || 'Bản mệnh')}</div><div class="center-sub">${escapeHTML(pillars.join(' · '))}</div><div class="center-facts"><span class="fact-chip">${escapeHTML(translate(chart.wuxingJuName))}</span><span class="fact-chip">Mệnh chủ ${escapeHTML(translate(chart.mingZhu))}</span><span class="fact-chip">Thân chủ ${escapeHTML(translate(chart.shenZhu))}</span></div></div>`;
    const b = chart.birthInfo;
    const shownDate = new Date(`${chart.ui.iso}T12:00:00`);
    $('#chartTitle').textContent = b.name ? `Lá số · ${b.name}` : 'Lá số của bạn';
    $('#chartMeta').textContent = `${shownDate.toLocaleDateString('vi-VN',{day:'2-digit',month:'long',year:'numeric'})} · ${chart.ui.clockTime} · ${hourNames[b.hour]} ${hourRanges[b.hour]} · ${b.gender === 'female' ? 'Nữ' : 'Nam'}${b.city ? ` · ${b.city}` : ''}${chart.ui.dateOffset ? ' · ngày Tý đã hiệu chỉnh' : ''}`;
    $('#chartDateLabel').textContent = `${String(b.day).padStart(2,'0')}.${String(b.month).padStart(2,'0')}.${b.year} · ${hourNames[b.hour]}`;
    $$('.palace-cell',board).forEach((cell) => cell.addEventListener('click',() => selectPalace(chart,cell.dataset.branch,cell)));
    const soul = chart.palaces.find((palace) => palace.isMingGong || palace.branch === chart.mingGongBranch);
    const soulBranch = soul ? branches[soul.branch] : '';
    if (soul) selectPalace(chart,soulBranch,$(`.palace-cell[data-branch="${soulBranch}"]`,board));
    renderInsight(chart,activeTab);
    chartSection.hidden = false;
  }
  function selectPalace(chart, branch, element) {
    $$('.palace-cell').forEach((cell) => cell.classList.toggle('selected',cell === element));
    const palace = chart.palaces.find((item) => branches[item.branch] === branch); if (!palace) return;
    const stars = getStarList(palace);
    const isBody = palace.isShenGong || palace.branch === chart.shenGongBranch;
    const age = palace.daXianAge;
    $('#detailName').textContent = `Cung ${titleCaseName(palace)}${isBody ? ' · Thân cư' : ''}`;
    $('#detailSub').textContent = `${stems[palace.stem]}${branch}${age ? ` · Đại hạn ${age[0]}–${age[1]} tuổi` : ''}${palace.isCurrentDaXian ? ' · Đại hạn hiện tại' : ''}`;
    $('#detailStars').innerHTML = stars.length ? stars.map((star) => {
      const hua = star.siHua ? translate(star.siHua) : '';
      return `<span class="detail-star ${hua ? 'mutagen' : ''}">${escapeHTML(translate(star.name))}${star.brightnessRaw ? ` · ${escapeHTML(translate(star.brightnessRaw))}` : ''}${hua ? ` · ${escapeHTML(hua)}` : ''}</span>`;
    }).join('') : '<span class="detail-star">Vô chính diệu</span>';
  }
  function getPalace(chart,name) { return chart.palaces.find((palace) => titleCaseName(palace) === name); }
  function insightText(chart,id) {
    const target = tabs.find((tab) => tab.id === id) || tabs[0];
    const palace = getPalace(chart,target.name) || getPalace(chart,'Mệnh');
    const major = getStarList(palace).filter((star) => star.type === 'major');
    const label = titleCaseName(palace);
    const copy = id === 'career' ? 'career' : id === 'wealth' ? 'wealth' : id === 'love' ? 'love' : id === 'personality' ? 'personality' : id === 'health' ? 'health' : 'overview';
    const start = `Luận giải ${escapeHTML(label)} theo ý nghĩa sao trong repo Tử Vi Đẩu Số gốc. Các sao chính đang hiện diện:`;
    const starReflection = major.length
      ? major.map((star) => {
          const reading = starReadings[star.name]?.[copy];
          return reading ? `<section class="reading-star"><h4>${escapeHTML(translate(star.name))}${star.siHua ? ` · Hóa ${escapeHTML(translate(star.siHua))}` : ''}</h4><p>${escapeHTML(reading)}</p></section>` : '';
        }).filter(Boolean).join('')
      : '<p>Cung vô chính diệu cần được xem cùng tam phương tứ chính và cung đối diện; riêng cung này chưa đủ để luận đoán.</p>';
    return `<p>${start}</p>${starReflection}<p>Đây là cách diễn giải Tử Vi truyền thống để tham khảo và tự chiêm nghiệm, không phải kết luận cố định.</p><div class="insight-callout">“Mệnh lý là góc nhìn văn hóa; lựa chọn thực tế vẫn nằm ở bạn.”</div>`;
  }
  function renderInsight(chart,id) {
    activeTab = id;
    $('#insightTabs').innerHTML = tabs.map((tab) => `<button class="insight-tab ${tab.id === id ? 'active' : ''}" role="tab" id="tab-${tab.id}" aria-selected="${tab.id === id}" aria-controls="insightCopy" data-tab="${tab.id}">${tab.label}</button>`).join('');
    $$('.insight-tab').forEach((tab) => tab.addEventListener('click',() => renderInsight(chart,tab.dataset.tab)));
    $('#insightCopy').setAttribute('aria-labelledby',`tab-${id}`);
    $('#insightCopy').innerHTML = insightText(chart,id);
  }
  function getSaved() { try { return JSON.parse(localStorage.getItem('menh-ban:charts') || '[]'); } catch { return []; } }
  function setSaved(charts) {
    try { localStorage.setItem('menh-ban:charts',JSON.stringify(charts)); } catch { showToast('Không thể lưu. Bộ nhớ trình duyệt có thể đã đầy.'); }
    renderSaved();
  }
  function renderSaved() {
    const charts = getSaved(), list = $('#savedList');
    $('#savedCount').textContent = String(charts.length);
    $('#savedTotal').textContent = `${charts.length} hồ sơ`;
    if (!charts.length) { list.innerHTML = '<div class="saved-empty"><span>冊</span><p>Lá số bạn lưu sẽ xuất hiện ở đây.</p></div>'; return; }
    list.innerHTML = charts.map((chart,index) => `<article class="saved-card"><span class="saved-card-mark">命</span><div class="saved-card-copy"><strong>${escapeHTML(chart.name || 'Lá số của tôi')}</strong><span>${escapeHTML(chart.iso.split('-').reverse().join('/'))} · ${escapeHTML(chart.clockTime)} · ${chart.gender === 'female' ? 'Nữ' : 'Nam'} · ${escapeHTML(chart.city || 'Không hiệu chỉnh')}</span></div><div class="saved-card-actions"><button data-load="${index}">Mở lá số</button><button class="delete-button" data-delete="${index}" aria-label="Xóa ${escapeHTML(chart.name || 'lá số')}">Xóa</button></div></article>`).join('');
    $$('[data-load]',list).forEach((button) => button.addEventListener('click',() => {
      if (!ready()) { showToast('Engine chưa sẵn sàng. Tải lại trang khi có kết nối mạng.'); return; }
      try { activeChart = makeChart(getSaved()[Number(button.dataset.load)]); renderBoard(activeChart); chartSection.scrollIntoView({behavior:'smooth',block:'start'}); }
      catch (error) { showToast(error.message || 'Không mở được lá số này.'); }
    }));
    $$('[data-delete]',list).forEach((button) => button.addEventListener('click',() => {
      const items = getSaved(); items.splice(Number(button.dataset.delete),1); setSaved(items); showToast('Đã xóa hồ sơ trên thiết bị.');
    }));
  }
  function readInput() {
    const iso = dateInput.value, clockTime = timeInput.value;
    const gender = $('input[name="gender"]:checked')?.value;
    if (!iso) throw new Error('Vui lòng chọn ngày sinh.');
    if (!clockTime) throw new Error('Vui lòng nhập giờ sinh.');
    const [year,month,day] = iso.split('-').map(Number);
    const probe = new Date(year,month-1,day);
    if (probe.getFullYear() !== year || probe.getMonth() !== month-1 || probe.getDate() !== day) throw new Error('Ngày sinh không hợp lệ.');
    if (year < 1900 || year > new Date().getFullYear()) throw new Error('Năm sinh cần nằm trong khoảng từ 1900 đến hiện tại.');
    const option = citySelect.selectedOptions[0];
    return {iso,clockTime,gender,name:$('#personName').value.trim(),longitude:citySelect.value,city:citySelect.value ? option.textContent : ''};
  }
  form.addEventListener('submit',(event) => {
    event.preventDefault(); setError('');
    try {
      const input = readInput();
      if (!ready()) { engineNote.hidden = false; engineNote.scrollIntoView({behavior:'smooth',block:'center'}); return; }
      activeChart = makeChart(input); renderBoard(activeChart); chartSection.scrollIntoView({behavior:'smooth',block:'start'});
    } catch (error) { setError(error.message || 'Không thể lập lá số. Vui lòng kiểm tra lại thông tin.'); }
  });
  $('#saveButton').addEventListener('click',() => {
    if (!activeChart) return;
    const ui = activeChart.ui, charts = getSaved();
    if (charts.some((item) => item.iso === ui.iso && item.clockTime === ui.clockTime && item.gender === ui.gender && item.name === ui.name && item.longitude === ui.longitude)) { showToast('Lá số này đã có trong hồ sơ đã lưu.'); return; }
    charts.unshift({...ui,savedAt:new Date().toISOString()}); setSaved(charts); showToast('Đã lưu riêng trên thiết bị này.');
  });
  $('#printButton').addEventListener('click',() => window.print());
  $('#downloadButton').addEventListener('click',() => {
    if (!activeChart) return;
    const chart = activeChart, b = chart.birthInfo;
    const xml = (value) => String(value ?? '').replace(/[&<>"']/g,(c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
    const palaceMap = new Map(chart.palaces.map((palace) => [branches[palace.branch],palace]));
    const cells = Object.entries(branchCoord).map(([branch,coord]) => {
      const palace = palaceMap.get(branch); if (!palace) return '';
      const [row,column] = coord.split('/').map(Number), x=(column-1)*300, y=(row-1)*250;
      const isMing = palace.branch === chart.mingGongBranch, isBody = palace.branch === chart.shenGongBranch;
      const stars = getStarList(palace).slice(0,7);
      const lines = stars.map((star,index) => `<text x="${x+20}" y="${y+78+index*29}" font-size="${index<2?21:17}" fill="${star.siHua?'#a63b2d':index<2?'#263e32':'#776b59'}">${xml(translate(star.name))}${star.siHua?` · ${xml(translate(star.siHua))}`:''}</text>`).join('');
      return `<g><rect x="${x}" y="${y}" width="300" height="250" fill="${isMing?'#eaf0e8':'#fbfaf5'}" stroke="#d8d4c5" stroke-width="2"/><text x="${x+20}" y="${y+34}" font-size="13" fill="#9d8b62">${xml(stems[palace.stem])}${branch}</text><text x="${x+20}" y="${y+57}" font-size="15" font-family="Arial,sans-serif" font-weight="600" fill="${isMing?'#49624d':'#70766c'}">${xml(titleCaseName(palace).toLocaleUpperCase('vi-VN'))}${isBody?' · THÂN':''}</text>${lines||`<text x="${x+20}" y="${y+91}" font-size="16" fill="#8a7760">Vô chính diệu</text>`}<text x="${x+20}" y="${y+231}" font-size="12" fill="#979184">${palace.isCurrentDaXian?'Đại hạn hiện tại':''}</text></g>`;
    }).join('');
    const date=new Date(`${chart.ui.iso}T12:00:00`).toLocaleDateString('vi-VN',{day:'2-digit',month:'long',year:'numeric'});
    const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="1000" viewBox="0 0 1200 1000"><rect width="1200" height="1000" fill="#fffefb"/>${cells}<rect x="300" y="250" width="600" height="500" fill="#f7f5ee" stroke="#d8d4c5" stroke-width="2"/><circle cx="600" cy="500" r="196" fill="none" stroke="#e6e0d1" stroke-width="2"/><circle cx="600" cy="500" r="166" fill="none" stroke="#e0dacb" stroke-width="1" stroke-dasharray="3 8"/><text x="600" y="430" text-anchor="middle" font-size="18" letter-spacing="4" fill="#9d8b62">MỆNH BÀN · TỬ VI ĐẨU SỐ</text><text x="600" y="488" text-anchor="middle" font-size="35" fill="#283a2c">${xml(b.name||'Bản mệnh')}</text><text x="600" y="530" text-anchor="middle" font-size="18" fill="#797d70">${xml(date)} · ${xml(hourRanges[b.hour])} · ${b.gender==='female'?'Nữ':'Nam'}</text><text x="600" y="574" text-anchor="middle" font-size="17" fill="#59634f">${xml(translate(chart.wuxingJuName))}　Mệnh chủ ${xml(translate(chart.mingZhu))}　Thân chủ ${xml(translate(chart.shenZhu))}</text><text x="600" y="980" text-anchor="middle" font-size="12" fill="#898575">Mệnh Bàn · Nội dung chiêm nghiệm mang tính tham khảo</text></svg>`;
    const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml;charset=utf-8'})), image=new Image();
    image.onload=()=>{const canvas=document.createElement('canvas');canvas.width=2400;canvas.height=2000;const ctx=canvas.getContext('2d');ctx.scale(2,2);ctx.drawImage(image,0,0,1200,1000);URL.revokeObjectURL(url);canvas.toBlob((png)=>{if(!png){showToast('Không thể tạo ảnh. Hãy dùng In / Lưu PDF.');return;}const a=document.createElement('a');a.href=URL.createObjectURL(png);a.download=`menh-ban-${chart.ui.iso}.png`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);});};
    image.onerror=()=>{URL.revokeObjectURL(url);showToast('Không thể xuất ảnh. Hãy dùng In / Lưu PDF.');};image.src=url;
  });
  $('#retryButton').addEventListener('click',() => location.reload());
  $('#menuButton').addEventListener('click',(event) => {const open=$('#sidebar').classList.toggle('open');event.currentTarget.setAttribute('aria-expanded',String(open));});
  $$('.nav-item').forEach((item) => item.addEventListener('click',() => {
    $$('.nav-item').forEach((nav) => nav.classList.toggle('active',nav===item));
    if (innerWidth<=850) {$('#sidebar').classList.remove('open');$('#menuButton').setAttribute('aria-expanded','false');}
  }));
  const today=new Date();dateInput.max=`${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;dateInput.value='1994-08-18';
  setTimeout(ready,100);renderSaved();
})();
